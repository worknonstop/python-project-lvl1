# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '<a href="https://codeclimate.com/github/worknonstop/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/c356ed621661028d1989/maintainability" /></a>\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/worknonstop/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/worknonstop/python-project-lvl1/actions)\n\n### How to install and game in brain-even:<br>\nhttps://asciinema.org/a/eWoYWhxN9jrvdajKo1IiZzj9h<br><br>\n### How to install and game in brain-calc:<br>\nhttps://asciinema.org/a/qVvLQTZUHk6M4htEsPcISZYQM<br><br>\n### How to install and game in brain-gcd:<br>\nhttps://asciinema.org/a/hkHX5rnXVr0JxCsy7rh1801OZ<br><br>\n',
    'author': 'Yuriy Y',
    'author_email': 'monkcrazy91@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)
