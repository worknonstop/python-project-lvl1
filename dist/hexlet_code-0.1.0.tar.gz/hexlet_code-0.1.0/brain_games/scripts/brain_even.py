#!usr/bin/env python3

from brain_games import source


def main():
    source.is_even()


if __name__ == "__main__":
    main()
