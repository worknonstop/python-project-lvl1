from brain_games.games import calc


def main():
    calc.calc_game()


if __name__ == "__main__":
    main()
