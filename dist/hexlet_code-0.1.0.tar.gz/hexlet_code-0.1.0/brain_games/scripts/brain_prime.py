#!usr/bin/env pytho3


from brain_games.games import prime


def main():
    prime.is_prime_game()


if __name__ == "__main__":
    main()
