<a href="https://codeclimate.com/github/worknonstop/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/c356ed621661028d1989/maintainability" /></a>
### Hexlet tests and linter status:
[![Actions Status](https://github.com/worknonstop/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/worknonstop/python-project-lvl1/actions)
